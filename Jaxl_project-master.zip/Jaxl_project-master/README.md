## User login with Email & OTP system
This Project implements 2-step verification to login system by sending One Time Passowrd (OTP) once the user has been partially verified as registered user in the first step.
## Frontend
HTML, CSS, Javascript and FETCH API for server side communication
## Backend
1. PHP
2. PHPMailer for sending OTP to the user 
## Mysql DB
one one user table with two fields email and otp.
since it's very tuny and basic database, therefore not uploaded to the github.

## P.S: 
You much privde your user name and password both for PHPMailer and database connectivity for this project to work.
You also need enable IMAP settings and Less secure app seeting for your google account. 
